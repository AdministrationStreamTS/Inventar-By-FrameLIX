/*
 * This file is part of Inventar+.
 *
 * along with Inventar+.  If not, see <>.
 */

package ru.endlesscode.rpginventory.utils;

import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Mockito;

import java.util.logging.Level;
import java.util.logging.Logger;

public class LogTest {

    private static final Logger logger = Mockito.mock(Logger.class);

    @BeforeClass
    public static void init() {
        Log.init(logger);
    }

    @Test
    public void shouldApplyArgsToMessage() {
        Exception exception = new Exception("Exception message");

        Log.i("Info {0}, {1}", 0, "arg1");
        Mockito.verify(logger).info("Info 0, arg1");

        Log.w(exception);
        Mockito.verify(logger).log(Level.WARNING, "Exception message", exception);

        Log.w("Warning {0}, {1}", 0, "arg1");
        Mockito.verify(logger).warning("Warning 0, arg1");

        Log.w(exception, "Warning {0}, {1}", 0, "arg1");
        Mockito.verify(logger).log(Level.WARNING, "Warning 0, arg1", exception);

        Log.s("Severe {0}, {1}", 0, "arg1");
        Mockito.verify(logger).severe("Severe 0, arg1");
    }

    @Test
    public void shouldApplyArgsToMessageWithQuotes() {
        Log.i("Info ''{0}'', \"{1}\"", "q", "qq");
        Mockito.verify(logger).info("Info 'q', \"qq\"");
    }

}
