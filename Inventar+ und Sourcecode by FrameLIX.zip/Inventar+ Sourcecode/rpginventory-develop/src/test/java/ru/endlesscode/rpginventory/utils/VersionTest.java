/*
 * This file is part of Inventar+.
 *
 * along with Inventar+.  If not, see <>.
 */

package ru.endlesscode.rpginventory.utils;

import org.junit.Assert;
import org.junit.Test;

public class VersionTest {

    @Test
    public void shouldParseVersionInRightFormat() {
        Version version = Version.parseVersion("1.12.2-SNAPSHOT");

        Assert.assertEquals(new Version(1, 12, 2, "SNAPSHOT"), version);
        Assert.assertTrue(version.hasQualifier());
    }

    @Test
    public void shouldParseVersionInRightFormatWithoutQualifier() {
        Version version = Version.parseVersion("1.12.2");

        Assert.assertEquals(new Version(1, 12, 2), version);
        Assert.assertFalse(version.hasQualifier());
    }

    @Test
    public void shouldParseVersionInRightFormatWithoutPatchVersion() {
        Version version = Version.parseVersion("1.12-SNAPSHOT");

        Assert.assertEquals(new Version(1, 12, 0, "SNAPSHOT"), version);
        Assert.assertTrue(version.hasQualifier());
    }

    @Test
    public void shouldParseVersionInRightFormatWithoutPatchVersionAndQualifier() {
        Version version = Version.parseVersion("1.12");

        Assert.assertEquals(new Version(1, 12, 0), version);
        Assert.assertFalse(version.hasQualifier());
    }

    @Test
    public void shouldParseVersionInRightFormatWithoutMinorVersion() {
        Version version = Version.parseVersion("1-SNAPSHOT");

        Assert.assertEquals(new Version(1, 0, 0, "SNAPSHOT"), version);
        Assert.assertTrue(version.hasQualifier());
    }

    @Test
    public void shouldParseVersionInRightFormatWithoutMinorVersionAndQualifier() {
        Version version = Version.parseVersion("1");

        Assert.assertEquals(new Version(1, 0, 0), version);
        Assert.assertFalse(version.hasQualifier());
    }

    @Test
    public void shouldConvertVersionToStringRight() {
        Assert.assertEquals("1.2.3", new Version(1, 2, 3).toString());
        Assert.assertEquals("1.2.3-q", new Version(1, 2, 3, "q").toString());
    }

    @Test
    public void comparingShouldBeRight() {
        Version version = new Version(2, 1, 4);

        Assert.assertEquals(0, version.compareTo(new Version(2, 1, 4)));
        Assert.assertEquals(0, version.compareTo(new Version(2, 1, 4, "qualifier")));
        Assert.assertEquals(-1, version.compareTo(new Version(2, 1, 5)));
        Assert.assertEquals(-1, version.compareTo(new Version(2, 2, 0)));
        Assert.assertEquals(-1, version.compareTo(new Version(3, 0, 0)));
        Assert.assertEquals(1, version.compareTo(new Version(2, 1, 3)));
        Assert.assertEquals(1, version.compareTo(new Version(2, 0, 9)));
        Assert.assertEquals(1, version.compareTo(new Version(1, 9, 9)));
    }

    @Test
    public void comparingWithStringShouldBeRight() {
        Version version = new Version(2, 1, 4);

        Assert.assertEquals(0, version.compareTo("2.1.4"));
        Assert.assertEquals(0, version.compareTo("2.1.4-qualifier"));
        Assert.assertEquals(-1, version.compareTo("2.1.5"));
        Assert.assertEquals(-1, version.compareTo("2.2.0"));
        Assert.assertEquals(-1, version.compareTo("3.0.0"));
        Assert.assertEquals(1, version.compareTo("2.1.3"));
        Assert.assertEquals(1, version.compareTo("2.0.9"));
        Assert.assertEquals(1, version.compareTo("1.9.9"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void shouldThrowExceptionWhenPassedWrongString() {
        Version.parseVersion("1.0.0.0");
    }

    @Test(expected = IllegalArgumentException.class)
    public void shouldThrowExceptionWhenPassedEmptyString() {
        Version.parseVersion("");
    }

    @Test(expected = IllegalArgumentException.class)
    public void shouldThrowExceptionWhenPassedOnlyQualifier() {
        Version.parseVersion("-SNAPSHOT");
    }

    @Test(expected = IllegalArgumentException.class)
    public void shouldThrowExceptionWhenPassedNegativeNumbers() {
        new Version(1, 0, -1);
    }

    @Test(expected = NullPointerException.class)
    public void shouldThrowExceptionWhenPassedNullQualifier() {
        //noinspection ConstantConditions
        new Version(1, 0, 0, null);
    }
}
