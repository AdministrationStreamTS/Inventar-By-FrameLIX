/*
 * This file is part of Inventar+.
 *
 * along with Inventar+.  If not, see <>.
 */

package ru.endlesscode.rpginventory.utils;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

/**
 */
public class CommandUtils {
    /**
     * Execute command from player to server
     *
     * @param player    The player
     * @param command   The command
     * @param runFromOp If true, command will be run from OP
     */
    public static void sendCommand(@NotNull Player player, String command, boolean runFromOp) {
        command = StringUtils.setPlaceholders(player, command);

        if (runFromOp) {
            Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), command);
        } else {
            player.performCommand(command);
        }
    }
}
