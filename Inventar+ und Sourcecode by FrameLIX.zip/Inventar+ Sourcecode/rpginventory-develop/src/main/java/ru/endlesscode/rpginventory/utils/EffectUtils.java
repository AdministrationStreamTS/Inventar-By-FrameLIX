/*
 * This file is part of Inventar+.
 *
 * along with Inventar+.  If not, see <>.
 */

package ru.endlesscode.rpginventory.utils;

import com.comphenix.packetwrapper.WrapperPlayServerTitle;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.wrappers.EnumWrappers;
import com.comphenix.protocol.wrappers.WrappedChatComponent;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import ru.endlesscode.inspector.bukkit.scheduler.TrackedBukkitRunnable;
import ru.endlesscode.rpginventory.RPGInventory;
import ru.endlesscode.rpginventory.compat.SoundCompat;
import ru.endlesscode.rpginventory.misc.config.Config;

import java.lang.reflect.InvocationTargetException;
import java.util.List;

/**
 */
public class EffectUtils {

    public static void playParticlesToAll(Particle particle, int particleNum, @NotNull Location location) {
        playParticlesToAll(particle, particleNum, location, 30.0D);
    }

    private static void playParticlesToAll(Particle particle, int particleNum, @NotNull Location location, double distance) {
        playParticlesToAll(particle, particleNum, location, LocationUtils.getRandomVector(), distance);
    }

    private static void playParticlesToAll(Particle particle, int particleNum, @NotNull Location location, @NotNull Vector direction, double distance) {
        for (Player player : LocationUtils.getNearbyPlayers(location, distance)) {
            playParticles(player, particle, particleNum, location, direction);
        }
    }

    private static void playParticles(Player player, Particle particle, int particleNum, Location location, Vector direction) {
        player.spawnParticle(particle, location, particleNum, direction.getX(), direction.getY(), direction.getZ());
    }

    public static void playSpawnEffect(Entity entity) {
        Location loc = entity.getLocation();

        entity.getWorld().playSound(loc, SoundCompat.ENDERMAN_TELEPORT.get(), 1, (float) (1.2 + Math.random() * 0.4));
        playParticlesToAll(Particle.EXPLOSION_LARGE, 3, loc);
    }

    public static void playDespawnEffect(Entity entity) {
        Location loc = entity.getLocation();

        entity.getWorld().playSound(loc, SoundCompat.ENDERMAN_TELEPORT.get(), 1, (float) (0.6 + Math.random() * 0.4));
        playParticlesToAll(Particle.SMOKE_NORMAL, 3, loc);
    }


    public static void showDefaultJoinMessage(Player player) {
        showJoinMessage(player, "default", null);
    }

    public static boolean showJoinMessage(Player player, String messageId, @Nullable Runnable callback) {
        String configPrefix = "join-messages." + messageId;
        if (Config.getConfig().getBoolean(configPrefix + ".enabled", false)) {
            EffectUtils.sendTitle(player,
                    Config.getConfig().getInt("join-messages.delay", 2),
                    Config.getConfig().getString(configPrefix + ".title"),
                    Config.getConfig().getStringList(configPrefix + ".text"),
                    callback);
            return true;
        } else {
            return false;
        }
    }

    private static void sendTitle(final Player player, int delay, String title, @NotNull final List<String> subtitles, @Nullable final Runnable callback) {
        if (delay < 2) {
            delay = 2;
        }

        final WrapperPlayServerTitle titlePacket = new WrapperPlayServerTitle();
        int time = (subtitles.size() == 0 ? delay : delay * subtitles.size()) - 1;
        try {
            WrapperPlayServerTitle resetPacket = new WrapperPlayServerTitle();
            resetPacket.setAction(EnumWrappers.TitleAction.RESET);
            ProtocolLibrary.getProtocolManager().sendServerPacket(player, resetPacket.getHandle());

            WrapperPlayServerTitle timesPacket = new WrapperPlayServerTitle();
            timesPacket.setAction(EnumWrappers.TitleAction.TIMES);
            timesPacket.setFadeIn(10);
            timesPacket.setFadeOut(10);
            timesPacket.setStay(20 * time);
            ProtocolLibrary.getProtocolManager().sendServerPacket(player, timesPacket.getHandle());

            title = StringUtils.coloredLine(StringUtils.setPlaceholders(player, title));
            titlePacket.setAction(EnumWrappers.TitleAction.TITLE);
            titlePacket.setTitle(WrappedChatComponent.fromChatMessage(StringUtils.coloredLine(title))[0]);
            ProtocolLibrary.getProtocolManager().sendServerPacket(player, titlePacket.getHandle());
        } catch (InvocationTargetException e) {
            throw new IllegalStateException("Unable to send packet", e);
        }

        new TrackedBukkitRunnable() {
            int line = 0;

            @Override
            public void run() {
                try {
                    if (line == subtitles.size()) {
                        this.cancel();
                        if (callback != null) {
                            callback.run();
                        }
                        return;
                    }

                    String subtitle = StringUtils.coloredLine(StringUtils.setPlaceholders(player, subtitles.get(line)));
                    titlePacket.setAction(EnumWrappers.TitleAction.SUBTITLE);
                    titlePacket.setTitle(WrappedChatComponent.fromChatMessage(subtitle)[0]);
                    ProtocolLibrary.getProtocolManager().sendServerPacket(player, titlePacket.getHandle());
                } catch (InvocationTargetException e) {
                    throw new IllegalStateException("Unable to send packet", e);
                }

                line++;
            }
        }.runTaskTimer(RPGInventory.getInstance(), 0, 20 * delay);
    }
}
