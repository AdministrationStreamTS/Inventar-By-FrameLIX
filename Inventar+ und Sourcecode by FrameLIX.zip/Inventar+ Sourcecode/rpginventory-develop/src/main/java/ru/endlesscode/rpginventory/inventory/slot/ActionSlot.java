/*
 * This file is part of Inventar+.
 *
 * along with Inventar+.  If not, see <>.
 */

package ru.endlesscode.rpginventory.inventory.slot;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import ru.endlesscode.rpginventory.inventory.InventoryManager;
import ru.endlesscode.rpginventory.utils.SafeEnums;

/**
 */
public class ActionSlot extends Slot {
    private final ActionType actionType;
    private final String command;
    private final boolean isGui;

    ActionSlot(String name, @NotNull ConfigurationSection config) {
        super(name, SlotType.ACTION, config);

        this.actionType = SafeEnums.valueOf(ActionType.class, config.getString("action"), "action type");
        this.command = config.getString("command");
        this.isGui = config.getBoolean("gui", false);
    }

    public void preformAction(@NotNull Player player) {
        if (this.isGui) {
            player.closeInventory();
        }

        if (this.actionType == ActionType.WORKBENCH) {
            InventoryManager.get(player).openWorkbench();
        } else if (this.actionType == ActionType.ENDERCHEST) {
            player.openInventory(player.getEnderChest());
        } else if (this.actionType == ActionType.COMMAND && command != null) {
            player.performCommand(command);
        }
    }

    private enum ActionType {
        WORKBENCH,
        ENDERCHEST,
        COMMAND
    }
}
