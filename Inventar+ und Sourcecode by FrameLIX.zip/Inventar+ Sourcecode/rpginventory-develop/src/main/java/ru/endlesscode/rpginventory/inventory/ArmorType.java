/*
 * This file is part of Inventar+.
 *
 * along with Inventar+.  If not, see <>.
 */

package ru.endlesscode.rpginventory.inventory;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import ru.endlesscode.rpginventory.inventory.slot.Slot;
import ru.endlesscode.rpginventory.inventory.slot.SlotManager;
import ru.endlesscode.rpginventory.utils.ItemUtils;

/**
 */
public enum ArmorType {
    HELMET,
    CHESTPLATE,
    LEGGINGS,
    BOOTS,
    UNKNOWN;

    @NotNull
    public static ArmorType matchType(ItemStack item) {
        if (ItemUtils.isEmpty(item)) {
            return UNKNOWN;
        }

        if (item.getType() == Material.ELYTRA) {
            return CHESTPLATE;
        }

        String[] typeParts = item.getType().name().split("_");
        String armorType = typeParts[typeParts.length - 1];

        try {
            return ArmorType.valueOf(armorType);
        } catch (IllegalArgumentException exception) {
            return UNKNOWN;
        }
    }

    @Nullable
    public static Slot getArmorSlotById(int id) {
        switch (id) {
            case 5:
                return SlotManager.instance().getSlot("helmet");
            case 6:
                return SlotManager.instance().getSlot("chestplate");
            case 7:
                return SlotManager.instance().getSlot("leggings");
            case 8:
                return SlotManager.instance().getSlot("boots");
            default:
                return null;
        }
    }

    @Nullable
    public ItemStack getItem(@NotNull Player player) {
        EntityEquipment equipment = player.getEquipment();
        if (equipment == null) {
            return null;
        }

        switch (this) {
            case HELMET:
                return equipment.getHelmet();
            case CHESTPLATE:
                return equipment.getChestplate();
            case LEGGINGS:
                return equipment.getLeggings();
            case BOOTS:
                return equipment.getBoots();
            default:
                return null;
        }
    }

    public int getSlot() {
        Slot temp = null;
        switch (this) {
            case HELMET:
                temp = SlotManager.instance().getSlot("helmet");
                break;
            case CHESTPLATE:
                temp = SlotManager.instance().getSlot("chestplate");
                break;
            case LEGGINGS:
                temp = SlotManager.instance().getSlot("leggings");
                break;
            case BOOTS:
                temp = SlotManager.instance().getSlot("boots");
        }

        return temp == null ? -1 : temp.getSlotId();
    }
}
