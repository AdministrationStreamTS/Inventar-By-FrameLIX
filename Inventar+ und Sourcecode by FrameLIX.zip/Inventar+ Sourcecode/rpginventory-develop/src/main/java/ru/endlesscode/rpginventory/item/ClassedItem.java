/*
 * This file is part of Inventar+.
 *
 * along with Inventar+.  If not, see <>.
 */

package ru.endlesscode.rpginventory.item;

import org.bukkit.configuration.ConfigurationSection;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 */
public class ClassedItem extends TexturedItem {
    private final int level;
    @Nullable
    private final List<String> classes;

    protected ClassedItem(Texture texture, ConfigurationSection config) {
        super(texture);

        this.level = config.getInt("level", -1);
        this.classes = config.contains("classes") ? config.getStringList("classes") : null;
    }

    public int getLevel() {
        return this.level;
    }

    @Nullable
    protected List<String> getClasses() {
        return this.classes;
    }

    @NotNull
    protected String getClassesString() {
        if (this.classes == null) {
            return "";
        }

        StringBuilder classesString = new StringBuilder();
        for (String theClass : this.classes) {
            if (classesString.length() > 0) {
                classesString.append(", ");
            }

            classesString.append(theClass);
        }

        return classesString.toString();
    }
}
