/*
 * This file is part of Inventar+.
 *
 * along with Inventar+.  If not, see <>.
 */

package ru.endlesscode.rpginventory.item;

/**
 */
public class TexturedItem {
    protected final Texture texture;

    protected TexturedItem(Texture texture) {
        this.texture = texture;
    }

    public short getTextureDurability() {
        return texture.getDurability();
    }
}
