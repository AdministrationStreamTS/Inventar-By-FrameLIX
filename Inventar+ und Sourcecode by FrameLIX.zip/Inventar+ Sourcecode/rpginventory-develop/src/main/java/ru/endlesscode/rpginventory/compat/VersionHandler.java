/*
 * This file is part of Inventar+.
 *

package ru.endlesscode.rpginventory.compat;

import org.bukkit.Bukkit;
import ru.endlesscode.rpginventory.utils.Version;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 */
public class VersionHandler {

    public static final int VERSION_1_11 = 1_11_00;
    public static final int VERSION_1_12 = 1_12_00;
    public static final int VERSION_1_13 = 1_13_00;
    public static final int VERSION_1_14 = 1_14_00;
    public static final int VERSION_1_15 = 1_15_00;
    public static final int VERSION_1_16 = 1_16_00;

    private static final Pattern pattern = Pattern.compile("(?<version>\\d\\.\\d{1,2}(\\.\\d)?)-.*");

    private static int versionCode = -1;

    public static boolean isNotSupportedVersion() {
        return getVersionCode() < VERSION_1_14 || getVersionCode() >= VERSION_1_16;
    }

    public static boolean isExperimentalSupport() {
        return getVersionCode() >= VERSION_1_15;
    }

    public static boolean isLegacy() {
        return getVersionCode() < VERSION_1_13;
    }

    public static int getVersionCode() {
        if (versionCode == -1) {
            initVersionCode();
        }

        return versionCode;
    }

    private static void initVersionCode() {
        Matcher matcher = pattern.matcher(Bukkit.getBukkitVersion());
        if (matcher.find()) {
            String versionString = matcher.group("version");
            versionCode = Version.parseVersion(versionString).getVersionCode();
        } else {
            versionCode = 0;
        }
    }
}
