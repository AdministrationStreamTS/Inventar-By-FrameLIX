/*
 * This file is part of Inventar+.
 *
 * along with Inventar+.  If not, see <>.
 */

package ru.endlesscode.rpginventory.event;

import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.bukkit.event.player.PlayerEvent;
import org.jetbrains.annotations.NotNull;

/**
 */
public class PlayerInventoryUnloadEvent extends PlayerEvent {
    private static final HandlerList handlers = new HandlerList();

    private PlayerInventoryUnloadEvent(Player who) {
        super(who);
    }

    @NotNull
    @SuppressWarnings("unused")
    public static HandlerList getHandlerList() {
        return handlers;
    }

    @NotNull
    @Override
    public HandlerList getHandlers() {
        return handlers;
    }

    @SuppressWarnings("unused")
    private static class Pre extends PlayerInventoryUnloadEvent {
        public Pre(Player who) {
            super(who);
        }
    }

    public static class Post extends PlayerInventoryUnloadEvent {
        public Post(Player who) {
            super(who);
        }
    }
}
