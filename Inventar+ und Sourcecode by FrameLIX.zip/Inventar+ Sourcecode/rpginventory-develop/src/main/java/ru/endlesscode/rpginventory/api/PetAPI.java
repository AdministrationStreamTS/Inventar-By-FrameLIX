/*
 * This file is part of Inventar+.
 *

package ru.endlesscode.rpginventory.api;

import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.Nullable;
import ru.endlesscode.rpginventory.inventory.InventoryManager;
import ru.endlesscode.rpginventory.inventory.PlayerWrapper;
import ru.endlesscode.rpginventory.pet.PetManager;
import ru.endlesscode.rpginventory.pet.PetType;
import ru.endlesscode.rpginventory.utils.ItemUtils;

/**
 */
@SuppressWarnings({"unused", "WeakerAccess"})
public class PetAPI {
    /**
     * Get pet spawn item from RPGInventory of specific player.
     *
     * @param player - not null player
     * @return ItemStack if player have pet spawn item, null - otherwise
     */
    @Nullable
    public static ItemStack getPetItem(Player player) {
        if (!InventoryManager.playerIsLoaded(player) || !PetManager.isEnabled()) {
            return null;
        }

        PlayerWrapper playerWrapper = InventoryManager.get(player);
        ItemStack petItem = playerWrapper.getInventory().getItem(PetManager.getPetSlotId());

        return ItemUtils.isEmpty(petItem) ? null : petItem;
    }

    /**
     * Get Pet of specific player.
     *
     * @param player - not null player
     * @return Pet if player have pet, null - otherwise
     */
    @Nullable
    public static PetType getPet(Player player) {
        return PetManager.getPetFromItem(PetAPI.getPetItem(player));
    }
}
