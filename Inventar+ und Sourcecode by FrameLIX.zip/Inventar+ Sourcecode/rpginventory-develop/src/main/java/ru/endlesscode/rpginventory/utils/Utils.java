/*
 * This file is part of Inventar+.
 *
 * along with Inventar+.  If not, see <>.
 */

package ru.endlesscode.rpginventory.utils;

import java.math.BigDecimal;

/**
 */
public class Utils {
    public static double round(double a, int scale) {
        return new BigDecimal(a).setScale(scale, BigDecimal.ROUND_HALF_UP).doubleValue();
    }
}
