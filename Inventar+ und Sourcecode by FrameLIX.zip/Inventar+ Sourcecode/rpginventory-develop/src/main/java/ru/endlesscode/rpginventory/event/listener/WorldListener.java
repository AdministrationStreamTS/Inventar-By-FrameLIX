/*
 * This file is part of Inventar+.
 *
 * along with Inventar+.  If not, see <>.
 */

package ru.endlesscode.rpginventory.event.listener;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.world.WorldSaveEvent;
import org.jetbrains.annotations.NotNull;
import ru.endlesscode.rpginventory.inventory.InventoryManager;
import ru.endlesscode.rpginventory.inventory.backpack.BackpackManager;

/**
 */
public class WorldListener implements Listener {
    @EventHandler
    public void onWorldSave(@NotNull WorldSaveEvent event) {
        if (!event.getWorld().equals(Bukkit.getWorlds().get(0))) {
            return;
        }

        BackpackManager.saveBackpacks();

        for (Player player : Bukkit.getServer().getOnlinePlayers()) {
            InventoryManager.savePlayerInventory(player);
        }
    }
}
