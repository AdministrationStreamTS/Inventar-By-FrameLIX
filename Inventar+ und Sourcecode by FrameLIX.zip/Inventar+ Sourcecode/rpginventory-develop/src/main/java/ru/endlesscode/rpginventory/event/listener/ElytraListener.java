/*
 * This file is part of Inventar+.
 *
 * along with Inventar+.  If not, see <>.
 */

package ru.endlesscode.rpginventory.event.listener;

import org.bukkit.Material;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityToggleGlideEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.jetbrains.annotations.NotNull;
import ru.endlesscode.rpginventory.compat.PlayerCompat;
import ru.endlesscode.rpginventory.inventory.InventoryManager;
import ru.endlesscode.rpginventory.inventory.PlayerWrapper;
import ru.endlesscode.rpginventory.utils.LocationUtils;

public class ElytraListener implements Listener {

    @EventHandler(ignoreCancelled = true)
    public void onPlayerFall(@NotNull PlayerMoveEvent event) {
        Player player = event.getPlayer();
        if (!InventoryManager.playerIsLoaded(player) || player.isFlying()
                || player.getVehicle() != null) {
            return;
        }

        PlayerWrapper playerWrapper = InventoryManager.get(player);
        boolean endFalling = false;
        if (!player.isOnGround()) {
            if (playerIsSneakOnLadder(player) || isPlayerCanFall(player)) {
                playerWrapper.onFall();
            } else if (!player.isGliding()) {
                endFalling = true;
            }
        } else if (playerWrapper.isFalling()) {
            endFalling = true;
        }

        if (endFalling) {
            playerWrapper.setFalling(false);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onEntityToggleGlide(@NotNull EntityToggleGlideEvent event) {
        if (event.getEntityType() != EntityType.PLAYER) {
            return;
        }

        Player player = (Player) event.getEntity();
        if (!InventoryManager.playerIsLoaded(player)) {
            return;
        }

        if (event.isGliding()) {
            PlayerWrapper playerWrapper = InventoryManager.get(player);
            playerWrapper.onStartGliding();
        }
    }

    private boolean isPlayerCanFall(@NotNull Player player) {
        double playerWidth = PlayerCompat.getWidth(player);
        return !LocationUtils.isUnderAnyBlockHonestly(player.getLocation(), playerWidth, 3)
                && !playerIsOnLadder(player);
    }

    private boolean playerIsSneakOnLadder(Player player) {
        return player.isSneaking() && playerIsOnLadder(player);
    }

    private boolean playerIsOnLadder(Player player) {
        return player.getLocation().getBlock().getType() == Material.LADDER;
    }
}
