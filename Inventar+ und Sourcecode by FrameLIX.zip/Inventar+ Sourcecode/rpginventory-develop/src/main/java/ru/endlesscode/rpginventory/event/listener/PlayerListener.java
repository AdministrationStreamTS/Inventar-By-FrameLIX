/*
 * This file is part of Inventar+.
 *
 */

package ru.endlesscode.rpginventory.event.listener;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.jetbrains.annotations.NotNull;
import ru.endlesscode.rpginventory.RPGInventory;
import ru.endlesscode.rpginventory.inventory.InventoryManager;
import ru.endlesscode.rpginventory.inventory.InventorySaver;
import ru.endlesscode.rpginventory.utils.PlayerUtils;

/**
 */
public class PlayerListener implements Listener {
    @EventHandler
    public void onCommand(@NotNull PlayerCommandPreprocessEvent event) {
        Player player = event.getPlayer();
        if (InventoryManager.isAllowedWorld(player.getWorld()) && !InventoryManager.playerIsLoaded(player)) {
            PlayerUtils.sendMessage(player, RPGInventory.getLanguage().getMessage("error.rp.denied"));
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOW)
    public void onPlayerDead(@NotNull PlayerDeathEvent event) {
        Player player = event.getEntity();
        if (InventoryManager.playerIsLoaded(player)) {
            InventorySaver.save(player, event.getDrops(),
                    RPGInventory.getPermissions().has(player, "rpginventory.keep.items") || event.getKeepInventory(),
                    RPGInventory.getPermissions().has(player, "rpginventory.keep.armor") || event.getKeepInventory(),
                    RPGInventory.getPermissions().has(player, "rpginventory.keep.rpginv") || event.getKeepInventory());
        }
    }

    @EventHandler(priority = EventPriority.LOW)
    public void onPlayerRespawn(@NotNull PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        if (InventoryManager.playerIsLoaded(player)) {
            InventorySaver.restore(player);
        }
    }
}
