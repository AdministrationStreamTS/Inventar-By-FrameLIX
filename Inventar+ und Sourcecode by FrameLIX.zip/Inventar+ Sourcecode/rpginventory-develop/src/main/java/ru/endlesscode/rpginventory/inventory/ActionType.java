/*
 * This file is part of Inventar+.
 *
 * along with Inventar+.  If not, see <>.
 */

package ru.endlesscode.rpginventory.inventory;

import org.bukkit.event.inventory.InventoryAction;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

/**
 */
public enum ActionType {
    SET,
    GET,
    DROP,
    OTHER;

    @NotNull
    @Contract(pure = true)
    public static ActionType getTypeOfAction(InventoryAction action) {
        if (action == InventoryAction.PLACE_ALL || action == InventoryAction.PLACE_ONE
                || action == InventoryAction.PLACE_SOME || action == InventoryAction.SWAP_WITH_CURSOR) {
            return SET;
        }

        if (action == InventoryAction.MOVE_TO_OTHER_INVENTORY || action == InventoryAction.PICKUP_ALL
                || action == InventoryAction.PICKUP_ONE || action == InventoryAction.PICKUP_SOME
                || action == InventoryAction.PICKUP_HALF || action == InventoryAction.COLLECT_TO_CURSOR) {
            return GET;
        }

        if (action == InventoryAction.DROP_ALL_CURSOR || action == InventoryAction.DROP_ALL_SLOT
                || action == InventoryAction.DROP_ONE_CURSOR || action == InventoryAction.DROP_ONE_SLOT) {
            return DROP;
        }

        return OTHER;
    }
}
