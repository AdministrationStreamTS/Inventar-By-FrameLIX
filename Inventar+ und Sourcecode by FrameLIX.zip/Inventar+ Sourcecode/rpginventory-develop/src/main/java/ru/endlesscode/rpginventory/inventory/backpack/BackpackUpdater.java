/*
 * This file is part of Inventar+.
 *
 * along with Inventar.  If not, see <>.
 */

package ru.endlesscode.rpginventory.inventory.backpack;

import org.bukkit.inventory.Inventory;
import org.bukkit.scheduler.BukkitRunnable;
import ru.endlesscode.rpginventory.RPGInventory;

import java.util.Arrays;

/**
 */
public class BackpackUpdater extends BukkitRunnable {
    private final Inventory inventory;
    private final Backpack backpack;

    private static final int DELAY = 2;

    private BackpackUpdater(Inventory inventory, Backpack backpack) {
        this.inventory = inventory;
        this.backpack = backpack;
    }

    public static void update(Inventory inventory, Backpack backpack) {
        new BackpackUpdater(inventory, backpack).runTaskLater(RPGInventory.getInstance(), DELAY);
    }

    @Override
    public void run() {
        backpack.onUse();

        int backpackSize = backpack.getType().getSize();
        backpack.setContents(Arrays.copyOfRange(inventory.getContents(), 0, backpackSize));
    }
}
