/*
 * This file is part of Inventar+.
 *
 * along with Inventar+.  If not, see <>.
 */

package ru.endlesscode.rpginventory.misc.config;

import ru.endlesscode.rpginventory.utils.SafeEnums;

public enum VanillaSlotAction {

    /**
     * Do vanilla action.
     */
    DEFAULT,

    /**
     * Open Inventar+.
     */
    RPGINV;


    static VanillaSlotAction parseString(String stringValue) {
        return SafeEnums.valueOfOrDefault(VanillaSlotAction.class, stringValue, DEFAULT, "slot action");
    }

}
