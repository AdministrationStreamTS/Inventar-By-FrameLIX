/*
 * This file is part of Inventar+.
 *
 * along with Inventar+.  If not, see <>.
 */

package ru.endlesscode.rpginventory.pet;

import java.util.UUID;

public class Attributes {
    public static final String SPEED_MODIFIER = "RPGInventory Speed Bonus";
    public static final UUID SPEED_MODIFIER_ID = UUID.fromString("2deaf4fc-1673-4c5b-ac4f-25e37e08760f");

    static final double ONE_BPS = 0.10638297872;
    static final double GALLOP_MULTIPLIER = 4.46808510803;

    private Attributes() {
        // Shouldn't be instantiated
    }
}
